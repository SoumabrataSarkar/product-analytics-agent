# Run notes and evidence index

- Mode: independent. Authorized database read-only; no alternate database used.
- Start: before 2026-11-09 22:05:09 Asia/Kolkata (first recorded clock reading; exact start was not captured). End: 2026-11-09 22:07:03 Asia/Kolkata (last recorded clock reading before writing this note).
- Query attempts: 11; 10 successful, 1 failed. Each has a separate JSONL evidence log and request JSON. Successful outputs are untruncated. No database mutations or builds were run.
- Repository: /Users/soum/Documents/Github/product-analytics-agent. No .git metadata is present, so commit and download date cannot be determined; inspected on 2026-11-09. Current registry SHA-256: 4b5b2f0e881666570ace017c06ff1bca380fff83c8dfa679317706e6a8815554. Current builder SHA-256: 12fd6588547bdfe88d12a2d8180f4db4d4781c334dc24770bd937accbe5d84c2.
- Build 3a0dbed21d2f45958aefa2887a0cadd8 records builder SHA matching current file and registry SHA 57b21d71027782fc28c8ea7eea4eb0dd9ed18273577d81bf00eaded632ff1227, which differs from current registry. Build-time checks passed, but source fingerprints were not freshly recomputed; do not infer verified freshness.
- Snapshot source: dataset_metadata users_snapshot_at 2026-09-30T23:59:59Z; not a database hash. Layer inventory is in q01. Build status, definitions and full reconciliation are in q03.

| Check | Purpose | Outcome |
|---|---|---|
| 01 | Inventory Bronze, Silver, Gold and metadata | 20 Bronze views, 10 Silver and 8 Gold tables |
| 02 | Snapshot metadata | Declared snapshot as above |
| 03 | Build status, versions, reconciliation | Succeeded, checks recorded true |
| 04 | Relevant source schema | Marketing is channel/day; user source is first touch |
| 05 | Search columns using table-valued PRAGMA | Failed: not authorized by query tool; retained as evidence |
| 06 | Inspect event JSON keys | No campaign key |
| 07 | Purchases by acquisition source | Descriptive channel counts; not campaign attribution |
| 08 | Purchase and user/link coverage | 6,215 charges, 1,465 users |
| 09 | Relevant quality exceptions | 13 reviewed payment corrections |
| 10 | Alternative source and layer schema search | Only aggregate click-count fields matched; no campaign or UTM fields |
| 11 | Payment types and outcomes | 6,001 successful subscriptions, 214 successful PPV; 317 failed charges, 12 successful refunds |

Hypothesis ledger: campaign-to-user identifiers in available schema: rejected based on checks 04, 06, 10; channel reveals causal campaign: inconclusive, since a channel is not a campaign and no causal design is present. Stop early because essential evidence is unavailable. report-content.json is the source for the generated six-page report.
