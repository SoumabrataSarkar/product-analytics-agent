# Monthly active users

MAU rose every month, from 7,937 in April to 11,447 in September 2026, a gain of 3,510 (+44.2%). July had the smallest month-over-month increase (+162; +1.6%), before growth recovered in August. [Check 3]

| Month | MAU | Change | Change % | Unidentified sessions |
|---|---:|---:|---:|---:|
| Apr 2026 | 7,937 | - | - | 2,286 (6.5%) |
| May 2026 | 9,134 | +1,197 | +15.1% | 3,044 (7.6%) |
| Jun 2026 | 9,976 | +842 | +9.2% | 3,184 (7.4%) |
| Jul 2026 | 10,138 | +162 | +1.6% | 3,354 (7.6%) |
| Aug 2026 | 10,871 | +733 | +7.2% | 3,480 (7.5%) |
| Sep 2026 | 11,447 | +576 | +5.3% | 3,703 (7.6%) |


MAU v1.1 counts distinct resolved users with a session active span touching each complete UTC month; the window is [2026-04-01, 2026-10-01). Unidentified sessions are excluded. Session counts do not reveal the number of missing people. [Checks 3, 8]

June to July: 2,477 new plus 2,908 resurrected users minus 5,223 users active in June but not July = +162. April to September net growth by first-touch source: paid social +2,436, organic +561, paid search +480, unknown +33; these add to +3,510. These are accounting contributions, not causal attribution. [Checks 3, 6]

Gold matches a Silver recount each month. The build succeeded with recorded reconciliation checks. Metadata dates user, entitlement and catalog snapshots to 2026-09-30 23:59:59 UTC. The activity window is documented in the registry; synthetic coverage is asserted in metadata, not independently proved. The build registry hash differs from the current file, though both identify MAU v1.1; source fingerprints were not independently recomputed. One session spans August and September and is counted in both, contrary to the registry's stale caveat. [Checks 2, 4, 8]

There were 10,400 users registered before coverage, so April is not a zero-user startup; pre-April activity is unavailable. No activity or profile exceptions, ambiguous identity links, or user-link mismatches were found. Monitor unidentified-session share and investigate the July slowdown before attributing it to a particular cause. [Checks 5, 7]
