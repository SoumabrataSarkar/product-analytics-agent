# Run notes

- Mode: independent. Excluded evaluation files, prior reports, answer keys, generator README and question-specific investigation guides.
- Start: before 2026-11-09 22:23:05 IST (first recorded clock reading; exact start not captured).
- End: 2026-11-09 22:25:52 IST (report rendered and page count checked; final notes completed immediately after).
- Database queries: 8, all through evidence_query.py. All succeeded and returned untruncated results. JSON requests and corresponding JSONL evidence are numbered q01 through q08; report appendix indexes their purposes.
- Repository: downloaded directory has no Git metadata; commit and exact download date are unavailable. Directory timestamp observed 2026-11-09 22:16:57 IST (not proof of download time). Current registry SHA-256: 4b5b2f0e881666570ace017c06ff1bca380fff83c8dfa679317706e6a8815554. Builder SHA-256: 12fd6588547bdfe88d12a2d8180f4db4d4781c334dc24770bd937accbe5d84c2.
- Snapshot source: dataset_metadata specifies users, catalog and entitlement snapshot instants of 2026-09-30T23:59:59Z; these are metadata assertions, not verified file hashes. Activity coverage is the registry's [2026-04-01, 2026-10-01) UTC contract.
- Build: 3a0dbed21d2f45958aefa2887a0cadd8, succeeded 2026-11-09T11:16:56Z. Build-recorded registry SHA-256: 57b21d71027782fc28c8ea7eea4eb0dd9ed18273577d81bf00eaded632ff1227, differing from the local registry; builder hash matches. MAU 1.1 and growth accounting 1.0. Build reconciliation results and source fingerprints are recorded in q02, not independently recomputed.
- Layer inventory: 20 Bronze views, 10 Silver tables, 8 Gold tables; exact names and schemas in q01. Gold KPI and growth accounting used, with Silver validation.
- Hypotheses: paid-social source contribution supported as arithmetic (q06), July slowdown accounting supported (q03); causal mechanism not tested. Stop: trend and accounting answered, causal inference outside available evidence.
- PDF: 6 pages, rendered and inspected. Markdown is an accessible text version; report-content.json is the PDF source.
