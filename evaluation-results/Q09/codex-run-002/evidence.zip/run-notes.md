# Run notes

- Mode: independent; excluded evaluations, prior reports, answer keys, generator README and question-specific investigation guides.
- Start: 2026-11-09 22:23:09 IST (first recorded investigation timestamp).
- End: 2026-11-09 22:27:43 IST.
- SQL queries attempted: 10; successful: 10; errors: 0; truncated: 0.
- Repository: downloaded copy at /Users/soum/Documents/Github/product-analytics-agent-main 2; no Git metadata; AGENTS.md filesystem creation timestamp 2026-11-09 22:16:57 IST used as the available download-copy timestamp, not a verified upstream commit or download event.
- Database: /Users/soum/Documents/Codex/2026-11-07/referenced-chatgpt-conversation-this-is-an/outputs/pockettoons.sqlite; queried read-only.
- Snapshot: metadata users_snapshot_at 2026-09-30T23:59:59Z, assertion rather than a verified fingerprint. Build 3a0dbed21d2f45958aefa2887a0cadd8 succeeded; revenue_group 1.1.
- Current registry SHA-256: 4b5b2f0e881666570ace017c06ff1bca380fff83c8dfa679317706e6a8815554; build registry SHA-256: 57b21d71027782fc28c8ea7eea4eb0dd9ed18273577d81bf00eaded632ff1227. Builder hash matches build: 12fd6588547bdfe88d12a2d8180f4db4d4781c334dc24770bd937accbe5d84c2.

## Evidence index

- q01: table and view inventory; metadata schemas.
- q02: metadata snapshot and coverage labels.
- q03: build status, versions, and recorded reconciliation results.
- q04: monthly Gold gross, refunds, net.
- q05: Silver monthly revenue by product; validates q06.
- q06: Gold revenue by product; tests the refund decomposition hypothesis.
- q07: payment amount and outcome exceptions.
- q08: transaction IDs and timestamp coverage.
- q09: corrected source amounts and timing by month.
- q10: UTC monthly boundaries and startup subscriber counts.

Each query has a request JSON and a separate JSONL evidence record. Hypothesis that lower refunds increased the net change is supported arithmetically; why refunds fell is inconclusive.
