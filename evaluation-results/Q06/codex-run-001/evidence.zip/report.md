# Are more users new, retained or returning?

Retained users are the largest group in every measurable month, May–September 2026. Percentages are of identified monthly active users.

| Month | New | Retained | Returning | MAU |
|---|---:|---:|---:|---:|
| May | 2,201 (24.1%) | 4,757 (52.1%) | 2,176 (23.8%) | 9,134 |
| June | 2,653 (26.6%) | 4,867 (48.8%) | 2,456 (24.6%) | 9,976 |
| July | 2,477 (24.4%) | 4,753 (46.9%) | 2,908 (28.7%) | 10,138 |
| August | 2,949 (27.1%) | 4,415 (40.6%) | 3,507 (32.3%) | 10,871 |
| September | 1,720 (15.0%) | 5,071 (44.3%) | 4,656 (40.7%) | 11,447 |

Growth accounting v1.0: new signed up in the active month; retained were active in that and the prior month; returning (resurrected) signed up earlier and were inactive in the prior month. The last group includes 157 whose first observed session was September. Activity uses MAU v1.1. Each month is [start, next month start) UTC. April has no result because March is outside coverage. See checks 4 and 6.

September MAU grew by 576: 1,720 new + 4,656 returning − 5,800 users active in August but not September. No causal explanation is established. Do not sum distinct users across months.

September had 3,703 unidentified sessions touching the month, excluded from MAU; their distinct people and categories are unknown, so the ranking applies only to identified users. The retained–returning margin is 415. The Silver recount agrees with Gold and found no missing profiles, future signups, duplicate or null user-day keys, flagged activity rows or flagged profiles. Checks 5–10 contain details.

The database reports successful build 3a0dbed21d2f45958aefa2887a0cadd8, completed 2026-11-09T11:16:56Z, with passing growth and MAU reconciliation. Metadata declares users snapshot 2026-09-30T23:59:59Z and complete synthetic session coverage. These are assertions, not a verified content hash. The build registry hash differs from the local registry hash; current definitions have the same recorded versions and September was recounted, but full equivalence and source freshness were not independently verified. Check 3 records build metadata. Check 1 shows 20 Bronze views, 10 Silver tables, and 8 Gold tables.

Independent mode. Repository has no Git metadata; local directory timestamp 2026-11-09 20:12:48 IST is a copy-date proxy rather than a verified download date. Builder SHA-256 matches: 12fd6588547bdfe88d12a2d8180f4db4d4781c334dc24770bd937accbe5d84c2. Build registry SHA-256: 57b21d71027782fc28c8ea7eea4eb0dd9ed18273577d81bf00eaded632ff1227; current registry: 4b5b2f0e881666570ace017c06ff1bca380fff83c8dfa679317706e6a8815554.

Improve identity coverage and agree a stricter reactivation definition if first-time activity after signup should not count as returning. Numbered evidence JSONL files and requests form the evidence index.
