# Q02 run notes

- **Question:** "MAU is up 20% QoQ but revenue is flat. Board meeting Thursday. Figure out what's happening and what we should do about it."
- **Agent / mode:** Claude Code (Opus 5.5), independent mode. I did not read docs/evaluations/, examples/pockettoons/README.md, answer keys or earlier reports.
- **Start:** 2026-11-09T18:34:24Z (device clock, first command). **End:** 2026-11-09T18:44:11Z (after the final PDF render). Elapsed time is about 10 minutes.
- **Queries:** 18, all through tools/evidence_query.py. Every query returned status ok; none was truncated, failed or retried.
- **Database:** $HOME/mnt/outputs/pockettoons.sqlite, opened read-only and not modified.
- **Build:** layer_build_log build 3a0dbed21d2f45958aefa2887a0cadd8, succeeded 2026-11-09T11:16:56Z. Definitions: mau 1.1, activity_family 1.0, stickiness_and_engagement_rate 1.0, growth_accounting 1.0, revenue_group 1.1, funnel_and_lifecycle_group 1.0, engagement_group 1.0, supporting_metrics 1.1. Users snapshot 2026-09-30T23:59:59Z.
- **Repository version:** the local copy has no git metadata, so the commit cannot be verified. Files were copied at 2026-11-09 18:33 UTC.
  - The sha256 of docs/metrics/metric-registry.md is 4b5b2f0e…. docs/project-status.md identifies this as commit 7240dfe, a documentation-only change from the build-time registry 57b21d71….
  - The sha256 of examples/pockettoons/build_layers.py is 12fd6588…, which matches the build log.
- **Files:**
  - Q02_report.pdf: 9-page report from tools/report_pdf.py.
  - report_content.json: the content file for the report.
  - requests/qNN.json: the query inputs.
  - logs/qNN.jsonl: the evidence logs.
  - Helper scripts: mkq.py (writes the request files), run_q.sh (runs one query) and make_content.py (writes the first draft of the content; the JSON was then edited in place to fit 10 pages).
  - .preview/: low-resolution page images from layout checks. They could not be deleted because deletion is not permitted in this folder.

## Hypothesis to evidence index

| Hypothesis | Status | Evidence |
|---|---|---|
| Premise: MAU +20% QoQ, revenue flat | Confirmed: avg MAU 9,015.7 → 10,818.7 (+20.0%); net revenue $30,145.00 → $30,166.97 (+0.07%) | q01, q02, q17 |
| H1: Growth comes from a low-monetising channel (paid social) | Pattern supported (association) | q03, q05, q06, q07, q10 |
| H2: Revenue is capped by a flat subscriber base | Supported | q02, q04 |
| H3: The added users are low-quality or unengaged | Rejected as the main driver (small differences only) | q06, q11, q18 |
| H4: Paywall-to-purchase conversion deteriorated | Rejected | q04, q08 |
| H5: Paywall reach did not scale with MAU | Supported | q08, q10, q13, q14 |
| H6: Price, PPV or refunds reduced revenue | Rejected | q02, q04, q17 |
| H7: Fewer blocked-playback triggers explain low reach | Inconclusive | q09, q12 |
| H8: The content offer became more free | Rejected | q15 |
| H9: A measurement or data-quality artefact | Rejected | q01, q16 |

## Notes

- April 2026 is the start-up month for subscriptions (0 subscribers at 1 April). Funnel and cohort trends are read from May. The headline still holds without April: MAU +13.2% and monthly revenue -0.8%.
- One unidentified session spans the Aug/Sep boundary: gold_kpi_monthly has 3,703 unidentified sessions for September, against 3,702 sessions starting in September. This is immaterial, but it contradicts the registry caveat that no fixture session crosses a month boundary.
- tools/report_pdf.py deletes a temporary file next to its output, and deletion is not permitted in the connected folder. The PDF was therefore rendered to a private folder outside mnt/ with the unmodified tool and then copied into Q02. A layout preview used a copy of the tool with the page limit raised; the final PDF used the original tool and its 10-page limit.
