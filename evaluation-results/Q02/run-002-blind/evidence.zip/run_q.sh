#!/bin/bash
# usage: run_q.sh NN  (reads requests/qNN.json, writes logs/qNN.jsonl, prints result summary)
set -e
Q=$HOME/mnt/Documents/agent-runs/claude/round2/Q02
cd $HOME/mnt/Documents/agent-runs/claude/round2/repo
python3 tools/evidence_query.py --log $Q/logs/q$1.jsonl < $Q/requests/q$1.json
