"""Write a query request JSON. usage: python3 mkq.py NN < spec.json (spec omits database/snapshot defaults)."""
import json, sys, os
Q = os.path.expanduser("~/mnt/Documents/agent-runs/claude/round2/Q02")
spec = json.load(sys.stdin)
req = {"database": os.path.expanduser("~/mnt/outputs/pockettoons.sqlite"),
       "snapshot_id": spec.pop("snapshot_id", "layer build 3a0dbed21d2f45958aefa2887a0cadd8 (caller-asserted; see q01)"),
       "parameters": spec.pop("parameters", {}), "limitations": spec.pop("limitations", []),
       "metric_version": spec.pop("metric_version", "ad hoc"), "timeframe": spec.pop("timeframe", "2026-04 to 2026-09 UTC")}
req.update(spec)
json.dump(req, open(f"{Q}/requests/q{sys.argv[1]}.json", "w"), indent=1)
