# Evidence index — MAU vs revenue investigation (independent mode)

Snapshot: pockettoons.sqlite SHA-256 8d39e78bbaa756b594c9e38797490dc1879f2980a05f966aaf62d3919517790b; build 3a0dbed21d2f45958aefa2887a0cadd8 (122/122 checks). Repo commit 1fd5121.
Question received 2026-11-09 11:47 UTC; first query 11:48:22 UTC; last query 11:50:33 UTC (device clock). Logs record hypothesis_status at query time; final statuses are below.

| File | Layer | Metric versions | Status | Final hypothesis status | Rows | Truncated | ms | Purpose |
|---|---|---|---|---|---|---|---|---|
| q01_kpi_monthly.jsonl | gold | mau 1.1; revenue_group 1.1; supporting 1.1 | ok | baseline | 6 | False | 1.962 | Premise: monthly MAU, net revenue, payers, ARPU, ARPPU, subscribers |
| q02_quarter_premise.jsonl | gold | mau 1.1 (quarter avg); revenue_group 1.1 (quarter sum) | ok | baseline (premise verified) | 2 | False | 1.882 | Premise: quarter-average MAU and quarter-summed net revenue, QoQ change |
| q03_growth_accounting.jsonl | gold | growth_accounting 1.0 | ok | H1 Supported | 5 | False | 1.937 | H1: where MAU growth comes from (new/retained/resurrected/churned) |
| q04_subscriber_status.jsonl | gold | mau 1.1 (mau_monthly_by_subscriber_status) | ok | H1 Supported | 12 | False | 2.262 | H1: active users by subscriber status (overlapping slices, not summed) |
| q05_revenue_type.jsonl | gold | revenue_group 1.1; refund_rate, payment_failure_rate (supporting 1.1) | ok | H2 Rejected | 18 | False | 2.141 | H2: revenue by type, payers, refunds, failures |
| q06_segments_qavg.jsonl | gold | mau 1.1 (segment slices; quarter avg of monthly) | ok | H1 Supported; H3 (segment artifact) Rejected | 13 | False | 2.522 | Quarter-average active users by source, platform, country; change Q2->Q3 (activity-level slices overlap; not summed) |
| q07_cohorts.jsonl | gold | funnel_and_lifecycle_group 1.0 (conversion_30d, activation_7d, retention) | ok | H1 Supported | 6 | False | 2.25 | H1: cohort size, 7d activation, 30d subscription/paid conversion, D30 retention |
| q08_conv_by_source.jsonl | silver | paid_conversion_30d (funnel_and_lifecycle 1.0) by acquisition_source via silver_user_profile.first_paid_at | ok | H4 (paid_social mix only) Rejected | 26 | False | 26.734 | H4: is the Q3 conversion drop a paid_social mix effect or within every source? Totals reconcile to gold_cohorts |
| q09_funnel.jsonl | gold | paywall_funnel, paywall_exposure (funnel_and_lifecycle 1.0; engagement 1.0) | ok | H5 Supported (exposure flat) | 18 | False | 2.569 | H5: paywall exposure and paywall->checkout->purchase rates by month |
| q10_exposure_by_source.jsonl | silver | paywall_exposure (engagement 1.0) by acquisition_source; ad hoc slice | ok | H6 Supported | 32 | False | 12.877 | H6: distinct paywall-exposed users and purchases per month by acquisition source and whether user signed up that month |
| q11_content_all.jsonl | gold | engagement_group 1.0 (all row) | ok | H6 Supported (context) | 6 | False | 3.054 | H6: viewing volume and free-quota hit rate by month |
| q12_by_signup_period.jsonl | silver | mau 1.1 resolved users; paywall_exposure 1.0; ad hoc slice by signup period | ok | H6 Supported | 15 | False | 167.23 | H6: monthly active users, paywall-exposed users and purchased paywalls by signup period (pre-window / Q2 / Q3 / no users row) |
| q13_tier_changes.jsonl | bronze | n/a (content_tier_history audit) | ok | H7 Rejected (immaterial) | 3 | False | 4.994 | H7: tier periods starting after release, by month and tier (premium->free changes) |
| q14_newuser_behaviour.jsonl | silver | engagement_group 1.0 building blocks; ad hoc first-30-day comparison | ok | H6 Supported (mechanism) | 5 | False | 142.871 | H6 mechanism: in each signup cohort's first 30 days, share of users who hit the daily free quota, watch sub/ppv content, and see a paywall |
| q15_identity_coverage.jsonl | silver | mau 1.1 population rule (resolution coverage) | ok | H8 Rejected | 6 | False | 1503.67 | H8: share of sessions touching each month that are unidentified (excluded from MAU) |
| q16_blocked_vs_paywall.jsonl | bronze | n/a (raw event audit; ad hoc first-30-day comparison) | ok | H9 Rejected | 5 | False | 443.651 | H9: per cohort, users with playback_blocked (by reason) vs paywall_viewed vs checkout_started in first 30 days, from raw events (user_id populated only) |

Setup logs (database build check, not part of this investigation's hypotheses) are kept separately on the device scratch folder: s01–s04 (s01, s03 failed: blocked json_each / existing-file guard; retried as s03b).

## Timing
- Question received: ~2026-11-09T11:47Z (17:17 IST)
- First investigation query: 2026-11-09T11:48:22Z; last: 2026-11-09T11:50:33Z (device clock, from logs)
- Report doc and charts completed: 2026-11-09T11:58:27Z (container clock)

## Report
Claude Doc: https://claude.ai/artifact/AibnRPMsuLXmkodAD7MgXz

## Notes for reviewers
- Logs record hypothesis_status at query time ("H1 testing" etc.); the final statuses are the table above.
- Query tools were copied unchanged from repo commit 1fd5121 (SHA-256 verified) to a private scratch folder on the device; the database was opened read-only and not modified.
- Not read during the run: docs/evaluations/investigation-paths.md, examples/pockettoons/README.md, any evaluation answer keys, and the earlier eval-*/guided-* files in the outputs folder.

## Review follow-up checks (added after peer review of v1, logged separately in inv1-review/)
| Check | File | Layer | Purpose | Result |
|---|---|---|---|---|
| 17 | q17_first30d_exact_bounds.jsonl | silver | Rerun q14 with exact lower/upper time bounds | Identical results; no paywall views before signup; viewing remains day-level |
| 18 | q18_payment_correction_sensitivity.jsonl | silver | Size of 13 corrected payments by quarter | Q2 $71.92 (8), Q3 $49.95 (5); QoQ +0.15% if all excluded |
| 19 | q19_q2cohort_paywall_no_purchase.jsonl | silver | Q2 signups' paywalls, checkouts, charges by month | Aug–Sep: 183 checkouts, 0 linked purchases; charges have no checkout link (renewals) |
| 20 | q20_q2cohort_paywall_status.jsonl | silver | Subscriber status and payment attempts for those paywalls | No viewer was already a subscriber; Aug–Sep checkouts had no payment attempt |
| 21 | q21_checkout_without_attempt.jsonl | silver | Checkouts with no payment attempt by group/month | Common for all groups (pre-April 61–85% May–Sep); Q2 signups 100% Aug–Sep; unresolved |

## Versions
- v1 (original agent output): Claude Doc + first PDF sent in chat; unchanged.
- v2 (corrected after peer review): PocketToons-MAU-vs-revenue-investigation-v2.pdf (9 pages; awaits evaluator verification). Changes: causal wording softened; H6 "pattern supported"; H8/H9 inconclusive; conversion labelled May–Jun vs Jul–Aug with exclusions; $760 scenario compared with monthly revenue (≈7.6%); data-quality conclusions qualified and sized; Q2 checkout anomaly unresolved and prominent.
