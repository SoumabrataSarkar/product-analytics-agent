# Evidence index and run notes

Independent investigation. Start: exact start was not captured; the first recorded clock reading was 2026-11-09 16:28:31 UTC, after repository inspection began. End: 2026-11-09 16:29:59 UTC (artifact creation completed by this time). Ten evidence queries were executed; all succeeded without truncation. The database was opened through the repository's read-only evidence tool.

Repository: /Users/soum/Documents/Github/product-analytics-agent. This is a downloaded/extracted tree with no Git metadata, so its commit and actual download date cannot be determined. AGENTS.md filesystem creation/modification time was 2026-11-09 20:12:48 +05:30; this is an observed file timestamp, not proof of download date. Current builder SHA-256: 12fd6588547bdfe88d12a2d8180f4db4d4781c334dc24770bd937accbe5d84c2 (matches build). Current metric registry SHA-256: 4b5b2f0e881666570ace017c06ff1bca380fff83c8dfa679317706e6a8815554; build recorded 57b21d71027782fc28c8ea7eea4eb0dd9ed18273577d81bf00eaded632ff1227. Build records lifecycle 1.0 and supporting metrics 1.1. The effective cancellation count is ad hoc and unversioned.

Snapshot identifier: users_snapshot_at=2026-09-30T23:59:59Z from q02; an as-of assertion, not a verified database hash. Build 3a0dbed21d2f45958aefa2887a0cadd8 succeeded 2026-11-09 11:15:43–11:16:56 UTC. Build source fingerprints are recorded in q03 but were not independently recomputed. Documented activity coverage is [2026-04-01, 2026-10-01) UTC. All 20 Bronze views, 10 Silver tables and eight Gold tables are enumerated by q01; their recorded row counts and reconciliation are in q03.

The query wrapper incorrectly labelled every log's source_layer as metadata and left snapshot_id as pending after metadata was retrieved. These are caller labels, not SQL results. Correct labels: q01, q02, q03, q06 and q08 metadata; q04 and q07 Silver; q05 Gold; q09 Bronze; q10 Silver and Bronze. Apply the snapshot above to the investigation as a whole. The logs retain their original labels for audit transparency. The question timeframe is [2026-08-01T00:00:00Z, 2026-09-01T00:00:00Z).

- q01_schema: available objects; 40 returned, no truncation.
- q02_metadata: source as-of timestamps and coverage declarations.
- q03_build: build status, versions, fingerprints, counts and reconciliation.
- q04_effective: 113 completed cancellation access spells; other access-period endings examined.
- q05_gold: 92 August cancellation requests and 113 snapshot churned subscribers; distinct definitions.
- q06_source_schema: subscription history schema.
- q07_checks: 113 qualifying rows, 113 users and subscriptions, zero missing/invalid request timestamps or flagged rows.
- q08_build_use: all 7,096 access rows belong to recorded build.
- q09_source_recount: 113 cancellation status records ending in August, 113 users, none with access continuing through that end.
- q10_provenance: no mismatched or missing Bronze records for qualifying Silver rows.

No explanatory hypothesis was required for this single-period count. Source event completeness and historical overwrites remain unproven.
