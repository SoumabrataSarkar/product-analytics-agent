# Run notes

Independent mode. Start: 2026-11-09 22:10:04 IST (16:40:04 UTC); query phase ended: 2026-11-09 22:11:23 IST (16:41:23 UTC); end: 2026-11-09 22:12:18 IST (16:42:18 UTC). Six evidence queries; all succeeded, no truncation. The PDF was rendered and visually inspected.

Repository: /Users/soum/Documents/Github/product-analytics-agent; no Git metadata or commit available. Directory creation timestamp 2026-11-09 20:12:48 IST, approximate download date 2026-11-09. Builder SHA-256 12fd6588547bdfe88d12a2d8180f4db4d4781c334dc24770bd937accbe5d84c2 matches build metadata. Build registry SHA-256 57b21d71027782fc28c8ea7eea4eb0dd9ed18273577d81bf00eaded632ff1227; current registry SHA-256 4b5b2f0e881666570ace017c06ff1bca380fff83c8dfa679317706e6a8815554.

Database metadata snapshot users_snapshot_at 2026-09-30T23:59:59Z; this is an asserted metadata timestamp, not an independently verified database hash. Build 3a0dbed21d2f45958aefa2887a0cadd8 succeeded 2026-11-09 11:15:43 to 11:16:56 UTC. Definitions and source fingerprints, all table names, checks and row counts are preserved in q01 and q02. No causal hypotheses were tested for this count question.

Evidence index: q01 inventory; q02 metadata/build; q03 monthly platform counts; q04 Bronze/Silver reconciliation; q05 quality and coverage; q06 overlap sensitivity. Inputs and logs stored alongside this note.
