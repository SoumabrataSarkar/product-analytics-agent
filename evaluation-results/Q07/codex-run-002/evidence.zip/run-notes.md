# Investigation run

- Mode: independent. Excluded evaluation documents, previous investigation reports, answer keys, generator answer-bearing README, and question-specific guides.
- Start: 2026-11-09 22:20:08 IST (first captured clock reading; investigation began immediately before).
- End: 2026-11-09 22:23:10 IST (approximately; final report validation).
- SQL query attempts: 10; 9 successful and 1 failed (05_quality, incorrect column; corrected in 08). No successful query was truncated. Shell attempts that did not invoke the query tool are not counted.
- Repository: /Users/soum/Documents/Github/product-analytics-agent-main 2; no .git directory or available commit ID; repository file timestamps indicate downloaded/copied 2026-11-09 (not verified as actual download date).
- Current registry SHA-256: 4b5b2f0e881666570ace017c06ff1bca380fff83c8dfa679317706e6a8815554. Build registry SHA-256: 57b21d71027782fc28c8ea7eea4eb0dd9ed18273577d81bf00eaded632ff1227. Current and build builder SHA-256: 12fd6588547bdfe88d12a2d8180f4db4d4781c334dc24770bd937accbe5d84c2.
- Snapshot: dataset_metadata users_snapshot_at 2026-09-30T23:59:59Z; declared activity coverage [2026-04-01, 2026-10-01) UTC in catalog. Snapshot ID is an assertion, not a current hash. Build 3a0dbed21d2f45958aefa2887a0cadd8 succeeded 2026-11-09 11:16:56Z.
- Evidence index: 01 inventory; 02 metadata; 03 build and reconciliation; 04 cohort baseline; 05 failed quality query; 06 source segments and hypothesis; 07 exceptions; 08 corrected quality query; 09 Bronze canonical recount; 10 reviewed payment sensitivity. Each JSONL has SQL, status, result, and context; companion request JSON files retain inputs.
- Hypotheses: lower newer cohort rates supported (04, 09); source mix alone rejected as sufficient explanation (06); specific causal mechanism inconclusive (not tested).
- Evidence labels for source_layer are generic "See query"; actual sources are explicit in the SQL and the index above. The first three records contain prospective snapshot labels referring to checks 02–03; see metadata and build checks for the actual assertions.
